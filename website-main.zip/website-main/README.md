# WEBSITE
Repo for the website project

# DESIGN

The main folder will have 3 sub folders (html, css, js)

Each HTML file will have its own name and its respective css file will have the conventional name :
"style_htmlname.css", as for the js file "script_htmlname.js"

# EXAMPLE:

# in the html folder:
"login.html"
# in the css folder:
"style_login.css"
# in the js folder:
"script_login.js"

# ONLY USE GIT CLI TO PUSH/PULL the code
